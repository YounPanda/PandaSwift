//
//  PATabBarController.swift
//  Panda
//
//  Created by admin on 2020/7/12.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit

class PATabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.isTranslucent = false
        
        let home = HomeTableViewController()
        addChildViewController(
            home,
            title: "首页",
            image: UIImage(named: "tab_home"),
            selectedImage: UIImage(named: "tab_home_S")
        )
        
        let partTime = ClassificationViewController()
        addChildViewController(
            partTime,
            title: "分类",
            image: UIImage(named: "tab_class"),
            selectedImage: UIImage(named: "tab_class_S")
        )
        
        let collect = ClassificationViewController()
        addChildViewController(
            collect,
            title: "书架",
            image: UIImage(named: "tab_book"),
            selectedImage: UIImage(named: "tab_book_S")
        )
        
        let mine = ClassificationViewController()
        addChildViewController(
            mine,
            title: "我的",
            image: UIImage(named: "tab_mine"),
            selectedImage: UIImage(named: "tab_mine_S")
        )
    }
    
    func addChildViewController(_ childController: UIViewController, title:String?, image:UIImage?, selectedImage:UIImage?) {
        
        childController.title = title
        childController.tabBarItem = UITabBarItem(
            title: nil,
            image: image?.withRenderingMode(.alwaysOriginal),
            selectedImage: selectedImage?.withRenderingMode(.alwaysOriginal)
        )
        
        if UIDevice.current.userInterfaceIdiom == .phone {
            childController.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: 0, bottom: -6, right: 0)
        }
        addChild(UINavigationController(rootViewController: childController))
    }
    
}

extension PATabBarController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        guard let select = selectedViewController else { return .lightContent }
        return select.preferredStatusBarStyle
    }
}

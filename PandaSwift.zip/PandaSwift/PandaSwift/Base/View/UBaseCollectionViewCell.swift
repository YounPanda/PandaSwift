//
//  UBaseCollectionViewCell.swift
//  PandaSwift
//
//  Created by admin on 2020/7/13.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit
import Reusable

class UBaseCollectionViewCell: UICollectionViewCell, Reusable {

    override init(frame: CGRect) {
        super.init(frame: frame)
        configUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    open func configUI() {}
}

//extension UICollectionView {
//  func register<T: UICollectionViewCell>(_: T.Type, reuseIdentifier: String = String(describing: T.self)) {
//    self.register(T.self, reuseIdentifier: reuseIdentifier)
//  }
//
//  func dequeueReusableCell<T: UICollectionViewCell>(indexPath: IndexPath, reuseIdentifier: String = String(describing: T.self)) -> T {
//    return self.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! T
//  }
//}

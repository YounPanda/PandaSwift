//
//  VideoFilterViewController.swift
//  GPUImagePractice
//
//  Created by admin on 2020/7/10.
//  Copyright © 2020 admin. All rights reserved.
//

import UIKit
import GPUImage
import AVFoundation
import CoreImage
import Toast_Swift

/**
脸部识别
 */
class VideoFilterViewController: UIViewController {

    @IBOutlet weak var renderView: RenderView!
    @IBOutlet weak var faceDetectSwitch: UISwitch!
    
    let fbSize = Size(width: 640, height: 480)
    // 指定用于面部识别的检测器类型
    let faceDetector = CIDetector(ofType: CIDetectorTypeFace, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyLow])
    var shouldDetectFaces = true
    lazy var lineGenerator: LineGenerator = {
        let gen = LineGenerator(size: self.fbSize)
        gen.lineWidth = 5
        gen.lineColor = Color.green
        return gen
    }()
    let saturationFilter = SaturationAdjustment()
    let blendFilter = AlphaBlend()
    var camera: Camera!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        do {
            camera = try Camera(sessionPreset: .vga640x480)
            camera.runBenchmark = true
            camera.delegate = self
            camera --> saturationFilter --> blendFilter --> renderView
            lineGenerator --> blendFilter
            shouldDetectFaces = faceDetectSwitch.isOn
            camera.startCapture()
        } catch {
            fatalError("Could not initialize rendering pipeline: \(error)")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
          if let camera = camera {
              camera.stopCapture()
              camera.removeAllTargets()
          }
          
          super.viewWillDisappear(animated)
      }

    @IBAction func didSwitch(_ sender: UISwitch) {
        shouldDetectFaces = sender.isOn
        
        let docPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
         print("docPath == %@", docPath)
        
    }
    
    @IBAction func caputure(_ sender: AnyObject) {
         print("Capture")
        do {
            // 获取用户文档目录路径
            let documentsDir = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            print("documentsDir == %@", documentsDir)
            
            saturationFilter.saveNextFrameToURL(URL(string:"TestImage.png", relativeTo: documentsDir)!, format: .png)
            self.view.makeToast("视频帧保存在document目录中")
        } catch {
            print("Couldn't save image: \(error)")
        }
    }
}


extension VideoFilterViewController: CameraDelegate {
    func didCaptureBuffer(_ sampleBuffer: CMSampleBuffer) {
        guard shouldDetectFaces else {
            lineGenerator.renderLines([]) // clear
            return
        }
        if let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) {
            let attachments = CMCopyDictionaryOfAttachments(allocator: kCFAllocatorDefault, target: sampleBuffer, attachmentMode: CMAttachmentMode(kCMAttachmentMode_ShouldPropagate))!
            let img = CIImage(cvPixelBuffer: pixelBuffer, options: attachments as? [CIImageOption : Any])
            var lines = [Line]()
            for feature in (faceDetector?.features(in: img, options: [CIDetectorImageOrientation: 6]))! {
                if feature is CIFaceFeature { //当相机检测到脸部特征的物体时会进入
                    lines = lines + faceLines(feature.bounds)
                    DispatchQueue.main.async {
                       self.view.makeToast("识别到脸部特征")
                    }
                }
            }
            lineGenerator.renderLines(lines)
        }
    }

    func faceLines(_ bounds: CGRect) -> [Line] {
        // convert from CoreImage to GL coords
        let flip = CGAffineTransform(scaleX: 1, y: -1)
        let rotate = flip.rotated(by: CGFloat(-.pi / 2.0))
        let translate = rotate.translatedBy(x: -1, y: -1)
        let xform = translate.scaledBy(x: CGFloat(2/fbSize.width), y: CGFloat(2/fbSize.height))
        let glRect = bounds.applying(xform)

        let x = Float(glRect.origin.x)
        let y = Float(glRect.origin.y)
        let width = Float(glRect.size.width)
        let height = Float(glRect.size.height)

        let tl = Position(x, y)
        let tr = Position(x + width, y)
        let bl = Position(x, y + height)
        let br = Position(x + width, y + height)

        return [.segment(p1:tl, p2:tr),   // top
                .segment(p1:tr, p2:br),   // right
                .segment(p1:br, p2:bl),   // bottom
                .segment(p1:bl, p2:tl)]   // left
    }
}

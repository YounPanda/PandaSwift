//
//  ALImageFilter.swift
//  PandaSwift
//
//  Created by admin on 2020/7/14.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit
import GPUImage

class ALImageFilter: NSObject {
    public class func filter(tag: Int) -> BasicOperation {
        
        switch tag {
               case 0:
                   return SepiaToneFilter()
               case 1:
                   return LuminanceRangeReduction()
               case 2:
                   return Luminance()
               case 3:
                   
                   let filter3 = BrightnessAdjustment()
                   filter3.brightness = 0.8
                   return filter3
               case 4:
                
                    let filter4 = ExposureAdjustment()
                    filter4.exposure = 0.8
                    return filter4
                  
               case 5:
                
                let filter5 = ContrastAdjustment()
                filter5.contrast = 0.8
                return filter5
                
               case 6:
                
                let filter6 = ContrastAdjustment()
                filter6.contrast = 1.8
                return filter6
                
               case 7:
                
                let filter7 = SaturationAdjustment()
                filter7.saturation = 1.8
                return filter7
    
               case 8:
               
                let filter8 = SaturationAdjustment()
                filter8.saturation = 1.1
                return filter8
               
                case 9:
                
                    let filter9 = Sharpen()
                    filter9.sharpness = 3.7
                    return filter9
               
               default:
                   return SaturationAdjustment()
               }
           }
}

//
//  CameraFilterCollectionViewCell.swift
//  Panda
//
//  Created by admin on 2020/7/12.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit
import SnapKit
import GPUImage

class CameraFilterCollectionViewCell: UBaseCollectionViewCell {
    
    private var renderView: RenderView! = {
        let rv = RenderView.init(frame: CGRect(x: 0, y: 0, width: 70, height: 110))
        rv.fillMode = .preserveAspectRatioAndFill
        return rv
    }()
    
    override func configUI() {

        contentView.addSubview(renderView)
        renderView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
    
    var picture: PictureInput!
    var filterOperation: BasicOperation!
    {
        didSet {
            guard filterOperation != nil else { return }
            picture = PictureInput(image: UIImage(named: "lzl")!)
            picture --> filterOperation --> renderView
            picture.processImage()
        }
    }
}


// var maskSelectedView: UIView! = {
//    let mask = UIView()
//    mask.backgroundColor = UIColor(red: 174, green: 174, blue: 178, alpha: 0.5)
//
//    let image: UIImage = UIImage(named: "check")!
//    mask.layer.contents = image.cgImage
//    mask.layer.contentsGravity = CALayerContentsGravity.center
//    mask.isUserInteractionEnabled = false
//    mask.isHidden = true
//    return mask
//}()

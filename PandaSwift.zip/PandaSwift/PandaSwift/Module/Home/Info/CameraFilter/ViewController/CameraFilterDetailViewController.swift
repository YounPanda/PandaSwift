//
//  CameraFilterDetailViewController.swift
//  Panda
//
//  Created by admin on 2020/7/12.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit
import GPUImage

class CameraFilterDetailViewController: UIViewController {
    
    @IBOutlet weak var renderView: RenderView!
    @IBOutlet weak var bottomView: UIView!
    
        
    private lazy var collectionView: UICollectionView = {
        let lt = UICollectionViewFlowLayout()
        lt.scrollDirection = UICollectionView.ScrollDirection.horizontal
        lt.minimumInteritemSpacing = 10
        lt.minimumLineSpacing = 10
        let cw = UICollectionView(frame: CGRect.zero, collectionViewLayout: lt)
        cw.backgroundColor = UIColor.white
        cw.delegate = self
        cw.dataSource = self
        cw.showsHorizontalScrollIndicator = false
        cw.register(cellType: CameraFilterCollectionViewCell.self)
        return cw
    }()
    
    func configurationUI() {
        bottomView.addSubview(collectionView)
        collectionView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }

    var camera: Camera!
    var selectedFilter: BasicOperation = SaturationAdjustment()
    
    override func viewDidLoad() {
         super.viewDidLoad()
        
        configurationUI()
    
        do {
                   camera = try Camera(sessionPreset: .vga640x480)
                   camera.runBenchmark = true
                   
                   camera.addTarget(selectedFilter)
                   selectedFilter.addTarget(renderView)
                   camera.startCapture()
               } catch {
                   fatalError("Could not initialize rendering pipeline: \(error)")
               }
     }
    
    override func viewWillDisappear(_ animated: Bool) {
        if let camera = camera {
            camera.stopCapture()
            camera.removeAllTargets()
        }
        super.viewWillDisappear(animated)
    }
   
    // Filtering image for display
    // 进来的时候一次性加载完成，并将滤镜好的图片，存下来。存在缓存数组中
//    func handleImage() {
//        picture = PictureInput(image: UIImage(named: "lzl")!)
//        filter = SaturationAdjustment()
//        picture --> filter --> collectionView
//        picture?.processImage()
//    }

    
}

extension CameraFilterDetailViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filterValues().count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
          let cell = collectionView.dequeueReusableCell(for: indexPath, cellType: CameraFilterCollectionViewCell.self)
          let filterInList: BasicOperation = filterValues()[(indexPath as NSIndexPath).row]
          cell.filterOperation = filterInList
          return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 10, bottom: section == 0 ? 0 : 10, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 70, height: 110)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        collectionView.deselectItem(at: indexPath, animated: true)
        // 切换滤镜
        let filter = filterValues()[(indexPath as NSIndexPath).row]

        renderView.sources.removeAtIndex(0)
        camera --> filter --> renderView   
    }
}

// func filterValues() -> [String] {
//   let filters = [
//       "YuanTu",
//       "HuaiJiu",
//       "DiPian",
//       "HeiBai",
//       "FuDiao",
//       "MengLong",
//       "KaTong",
//       "TuQi",
//       "ShuiJin"
//    ]
//}

//有内存问题，所以改用已经滤镜好的图片来对实时相机进行滤镜操作
//    //对原始图片滤镜
    func filterValues() -> [BasicOperation] {

      let filter = SaturationAdjustment()
      let filter1 = SepiaToneFilter()           //黑白
      let filter2 = Luminance()                //黑白 亮度
      let filter6 = ContrastAdjustment()
      filter6.contrast = 1.8
      let filter7 = SaturationAdjustment()
      filter7.saturation = 2
      let filter8 = SaturationAdjustment()      //饱和度
      filter8.saturation = 1.1
      let filter9 = Sharpen()
      filter9.sharpness = 3.7
        let filters = [filter, filter1, filter2, filter6, filter7, filter8, filter9]
      return filters
    }


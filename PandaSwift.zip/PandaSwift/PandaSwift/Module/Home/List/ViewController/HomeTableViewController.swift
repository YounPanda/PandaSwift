//
//  HomeTableViewController.swift
//  Panda
//
//  Created by admin on 2020/7/12.
//  Copyright © 2020 shuxuan. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "CellId")
        tableView.separatorStyle = .none
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellId", for: indexPath)
        cell.textLabel?.text = titleDataSource[indexPath.row]
        cell.backgroundColor = cellBackgroundColor[indexPath.row]
        return cell
    }
    
    // MARK: - Table view delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == 0 {
            navigationController?.pushViewController(CameraFilterDetailViewController(), animated: true)
        } else {
            navigationController?.pushViewController(VideoFilterViewController(), animated: true)
        }
        
    }
    
    var titleDataSource = ["相机滤镜", "面部识别"]
    var cellBackgroundColor = [UIColor.lightGray, UIColor.gray]
}
